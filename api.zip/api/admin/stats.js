// ==========================================
// API: 获取统计数据
// ==========================================

import { db } from '../../lib/supabase.js';

export default async function handler(req, res) {
    if (req.method !== 'GET') {
        return res.status(405).json({ error: '方法不允许' });
    }

    try {
        const stats = await db.getStats();

        return res.status(200).json({
            success: true,
            stats: stats
        });

    } catch (error) {
        console.error('获取统计失败:', error);
        return res.status(500).json({
            error: '获取失败',
            message: error.message
        });
    }
}
