// ==========================================
// API: 后台上传库存文件
// ==========================================

import { db } from '../../lib/supabase.js';

export default async function handler(req, res) {
    if (req.method !== 'POST') {
        return res.status(405).json({ error: '方法不允许' });
    }

    try {
        const { password, contents } = req.body;

        // 验证管理员密码
        if (password !== process.env.ADMIN_PASSWORD && password !== 'admin123') {
            return res.status(401).json({ error: '密码错误' });
        }

        if (!contents || !Array.isArray(contents) || contents.length === 0) {
            return res.status(400).json({ error: '请提供文件内容' });
        }

        // 批量添加库存
        const files = await db.addFiles(contents);

        return res.status(200).json({
            success: true,
            count: files.length,
            message: `成功添加 ${files.length} 个库存`
        });

    } catch (error) {
        console.error('上传库存失败:', error);
        return res.status(500).json({
            error: '上传失败',
            message: error.message
        });
    }
}
