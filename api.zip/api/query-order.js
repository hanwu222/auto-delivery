// ==========================================
// API: 查询订单状态
// ==========================================

import { db } from '../lib/supabase.js';

export default async function handler(req, res) {
    // 支持GET和POST
    if (req.method !== 'GET' && req.method !== 'POST') {
        return res.status(405).json({ error: '方法不允许' });
    }

    try {
        const orderNo = req.method === 'GET' ? req.query.orderNo : req.body.orderNo;

        if (!orderNo) {
            return res.status(400).json({ error: '请提供订单号' });
        }

        // 查询订单
        const order = await db.getOrder(orderNo);

        if (!order) {
            return res.status(404).json({ error: '订单不存在' });
        }

        // 返回订单信息
        return res.status(200).json({
            success: true,
            order: {
                orderNo: order.order_no,
                status: order.status,
                amount: order.amount,
                fileContent: order.file_content,
                createdAt: order.created_at,
                paidAt: order.paid_at,
                deliveredAt: order.delivered_at
            }
        });

    } catch (error) {
        console.error('查询订单失败:', error);
        return res.status(500).json({
            error: '查询失败',
            message: error.message
        });
    }
}
