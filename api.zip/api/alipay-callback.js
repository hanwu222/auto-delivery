// ==========================================
// API: 支付宝支付回调（自动发货）
// ==========================================

import { alipay } from '../lib/alipay.js';
import { db } from '../lib/supabase.js';

export default async function handler(req, res) {
    // 仅允许POST请求
    if (req.method !== 'POST') {
        return res.status(405).send('fail');
    }

    try {
        // 验证支付宝签名
        const isValid = alipay.checkNotifySign(req.body);

        if (!isValid) {
            console.error('支付宝签名验证失败');
            return res.status(400).send('fail');
        }

        const {
            out_trade_no,  // 商户订单号
            trade_no,      // 支付宝交易号
            trade_status,  // 交易状态
            total_amount   // 付款金额
        } = req.body;

        // 只处理支付成功的通知
        if (trade_status !== 'TRADE_SUCCESS') {
            return res.status(200).send('success');
        }

        // 查询订单
        const order = await db.getOrder(out_trade_no);

        if (!order) {
            console.error('订单不存在:', out_trade_no);
            return res.status(404).send('fail');
        }

        // 如果订单已处理，直接返回成功
        if (order.status === 'delivered') {
            return res.status(200).send('success');
        }

        // 验证金额
        if (parseFloat(total_amount) !== parseFloat(order.amount)) {
            console.error('金额不匹配:', total_amount, order.amount);
            return res.status(400).send('fail');
        }

        // 获取可用库存
        const file = await db.getAvailableFile();

        if (!file) {
            console.error('库存不足');
            // 更新订单状态为已支付但库存不足
            await db.updateOrder(out_trade_no, {
                status: 'paid',
                trade_no: trade_no,
                paid_at: new Date().toISOString()
            });
            return res.status(200).send('success');
        }

        // 标记文件已售出
        await db.markFileSold(file.id, order.id);

        // 更新订单状态为已发货
        await db.updateOrder(out_trade_no, {
            status: 'delivered',
            trade_no: trade_no,
            file_id: file.id,
            file_content: file.content,
            paid_at: new Date().toISOString(),
            delivered_at: new Date().toISOString()
        });

        console.log('自动发货成功:', out_trade_no);
        return res.status(200).send('success');

    } catch (error) {
        console.error('处理支付回调失败:', error);
        return res.status(500).send('fail');
    }
}
