// ==========================================
// API: 创建订单并生成支付二维码
// ==========================================

import { alipay, generateOrderNo } from '../lib/alipay.js';
import { db } from '../lib/supabase.js';
import QRCode from 'qrcode';

export default async function handler(req, res) {
    // 仅允许POST请求
    if (req.method !== 'POST') {
        return res.status(405).json({ error: '方法不允许' });
    }

    try {
        const { contact } = req.body;

        if (!contact) {
            return res.status(400).json({ error: '请提供联系方式' });
        }

        // 生成订单号
        const orderNo = generateOrderNo();

        // 固定金额45元
        const amount = 45.00;
        const subject = '成品账号';

        // 创建订单记录
        await db.createOrder({
            order_no: orderNo,
            contact: contact,
            amount: amount,
            status: 'pending'
        });

        // 调用支付宝当面付API生成二维码
        const qrCodeUrl = await alipay.createQrCode(orderNo, amount, subject);

        // 生成二维码图片（base64）
        const qrCodeImage = await QRCode.toDataURL(qrCodeUrl);

        return res.status(200).json({
            success: true,
            orderNo: orderNo,
            amount: amount,
            qrCodeUrl: qrCodeUrl,
            qrCodeImage: qrCodeImage
        });

    } catch (error) {
        console.error('创建订单失败:', error);
        return res.status(500).json({
            error: '创建订单失败',
            message: error.message
        });
    }
}
